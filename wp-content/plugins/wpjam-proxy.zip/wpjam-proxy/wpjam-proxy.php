<?php
/*
Plugin Name: WPJAM PHP 代理
Plugin URI: http://blog.wpjam.com/project/wpjam-proxy/
Description: 使用自建的 PHP 代理程序彻底解决 429 Too Many Requests 问题。
Version: 1.0
Author: Denis
Author URI: http://blog.wpjam.com/
*/
add_filter('pre_http_request', function($pre, $parsed_args, $url){
	$host	= parse_url($url, PHP_URL_HOST);

	if(!in_array($host, ['api.wordpress.org', 'downloads.wordpress.org'])){
		return $pre;
	}

	$proxy_url	= wpjam_basic_get_setting('proxy_url');

	if(!$proxy_url){
		return $pre;
	}

	return wp_remote_request($proxy_url.'?url='.urlencode($url), $parsed_args);
}, 10, 3);

if(is_admin()){
	add_filter('wpjam_basic_sub_pages',function($subs){
		$subs['wpjam-php-proxy']	= [
			'menu_title'	=>'代理设置',
			'function'		=>'option', 
			'option_name'	=>'wpjam-basic', 
			'page_file'		=>__DIR__.'/settings.php'
		];

		return $subs;
	});
}