<?php
if(empty($_GET['url'])){
    die('error.');
}

$url	= $_GET['url'];
$urls	= parse_url($url);

if($urls['host'] !== 'api.wordpress.org' && $urls['host']!=='downloads.wordpress.org'){
    die('error..');
}

if(!empty($_POST)) {
    $query	= http_build_query($_POST);

    $options['http'] = array(
        'timeout'	=> 20,
        'method'	=> 'POST',
        'header'	=> 'Content-type:application/x-www-form-urlencoded',
        'content'	=> $query
    );

    $context = stream_context_create($options);
}else{
    $context = null;
}

$result	= file_get_contents($url, false, $context);

$response_headers	= $http_response_header;

foreach($response_headers as $response_header){
	header($response_header);
}

echo $result;