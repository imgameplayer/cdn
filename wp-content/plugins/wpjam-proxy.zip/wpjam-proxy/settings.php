<?php
add_filter('wpjam_basic_setting', function (){
	$fields = ['proxy_url'	=> ['title'=>'PHP 代理地址',	'type'=>'url']];

	$summary	= '使用<strong>自建的 PHP 代理程序</strong>彻底解决 429 Too Many Requests 问题。<br />代理的 PHP 文件为 wp-proxy.php，在插件文件夹中，请放到国外服务器，然后将具体的地址填到下面输入框。';
	
	return compact('summary', 'fields');
});
